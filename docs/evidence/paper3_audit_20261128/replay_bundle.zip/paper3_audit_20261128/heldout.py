"""Paper III only. Reuse frozen development functions and Paper III prediction index."""
import audit as a
import numpy as np
import h5py, hashlib, time
from pathlib import Path
r=a.ref
r.c.require_compute()
start=time.monotonic()
ctrl=a.read(a.ROOT/'freeze.json')
assert a.digest(Path(a.__file__))==ctrl['source']
protocol=a.REPO/'docs/evidence/paper3_audit_20261128/heldout_protocol.md'
assert a.digest(protocol)=='583c00828c2b00f3d779eda974e7e8b802d4f49482c083d99d45cd2f00655a92'
root=a.BASE/'lowz_cfm_blind_confirmation_v1'
geom=root/'GEOMETRY_FROZEN.json'
idx=a.REPO/'docs/evidence/lowz_blind_cfm_prediction_index.json'
assert a.digest(geom)=='eb20683dbbf052f19ec651b8711c403eab3f75a967d235faf12011f316b2e737'
assert a.digest(idx)=='e9c78744e3c45b6679dbe42288f95f37d30f1821efc9ace6ddd9ab4f40f52397'
lookup={(ph,cap,i):(p,d,t) for ph,cap,i,p,d,t in a.read(idx)['rows']}
fit=a.BASE/'lowz_count_reference_61848915/TRAIN_ONLY.npz'
assert a.digest(fit)==ctrl['fit']
coef=np.load(fit)['coef']
a.save('heldout_freeze.json',dict(protocol=a.digest(protocol),development=a.digest(a.ROOT/'freeze.json'),source=a.digest(Path(__file__)),geometry=a.digest(geom),index=a.digest(idx)))
bank={}
for ph in r.c.TRAIN:
    for row,(x,*_) in r.groups(ph):
        y=r.truth(ph,row)
        bank.setdefault(row['pair_id'].split('_',1)[1],[]).append((r.encode(y.reshape(-1,4)).reshape(y.shape)-x@coef).astype('f4'))
for ph in ('ph018','ph019'):
    score=root/'blind_score_61911489'
    truth=np.load(score/(ph+'_truth.npy'))
    panel=a.read(geom)['phases'][ph]['pairs']
    old={(p['pair'],p['shell']):p for p in a.read(score/(ph+'_scores.json'))['rows'] if p['method']=='cfm' and p['weighting']=='cells'}
    assert truth.shape==(16,32,16,16,4) and len(panel)==16
    records=[]
    for j,row in enumerate(panel):
        cap=row['cap'];pair=row['pair_id']
        with h5py.File(root/ph/cap/'NATIVE.h5') as raw:
            x,z,s,sm,n=r.observations(raw,row)
        m=(z>=0)&(z<5)&(s>0)
        fields=[]
        for i in range(32):
            d=root/ph/cap/'predictions'/f'draw_{i:03d}'
            assert tuple(a.digest(d/p) for p in ['INPUTS.json','density/COMPLETE.json','tides/COMPLETE.json'])==lookup[ph,cap,i]
            with h5py.File(d/'density/FIELD.h5') as f,h5py.File(d/'tides/COMPLETED_FIELD.h5') as g:
                sl=r.p.cuts(row,f.attrs['origin_mpc_h'])
                np.testing.assert_array_equal(f['support'][sl]>0,s>0)
                fields.append(np.concatenate([f['rho'][(0,*sl)][...,None],g['eigenvalues'][(0,*sl)]],axis=-1))
        fields=np.stack(fields)
        assert np.isfinite(fields[:,m]).all() and (np.diff(fields[:,m,1:],axis=-1)>=0).all()
        with h5py.File(root/'matched_reference_v1'/f'{ph}_{cap}.h5') as h:
            for k in range(5):
                mask=(z==k)&m
                if not mask.any(): continue
                np.testing.assert_array_equal(h[pair+'/'+str(k)+'/flat_cell'][:],np.flatnonzero(mask))
                bias=(fields[:,mask].astype('f8').mean(0)-truth[j][mask]).mean(0)
                np.testing.assert_allclose(bias,old[pair,k]['bias'],atol=2e-7,rtol=0)
        raw=x@coef+np.array(bank[pair.split('_',1)[1]])
        q,b,u,v=np.moveaxis(raw,-1,0)
        base=np.stack([np.exp(q),b-np.exp(u),b,b+np.exp(v)],-1)
        inv=a.rank(base).argsort(0)
        rec=dict(phase=ph,pair=pair,redshift=row['redshift'],support=row['support_stratum'],cells=int(m.sum()),mask_hash=hashlib.sha256(m.tobytes()).hexdigest(),truth={str(d):a.cov(a.fil(truth[j])[None],m,d)[0] for d in (1,2,4)},scores=[])
        for ids in ctrl['subsets']:
            f=fields[ids]
            ecc=a.rearrange(f,np.take_along_axis(a.rank(f),inv,axis=0))
            ensembles={'cfm':a.fil(f),'baseline':a.fil(base),'ecc':a.fil(ecc)}
            for seed in ctrl['seeds']:
                rng=np.random.default_rng([seed,int(ph[2:]),int(hashlib.sha256(pair.encode()).hexdigest()[:8],16)])
                ensembles['shuffle'+str(seed)]=a.fil(a.rearrange(f,rng.random(f.shape[:-1]).argsort(0)))
            rec['scores'].append({name:{str(d):a.cov(v,m,d).tolist() for d in (1,2,4)} for name,v in ensembles.items()})
        records.append(rec)
    a.save(ph+'.json',records)
    print(ph,'completed',flush=True)
a.save('heldout_complete.json',dict(seconds=time.monotonic()-start,freeze=a.digest(a.ROOT/'heldout_freeze.json'),files={ph:a.digest(a.ROOT/(ph+'.json')) for ph in ('ph018','ph019')},checks='exact frozen flat-cell identity and full-ensemble original marginal signed bias per shell and region; tuple inversion and filament counts for all ECC and shuffled ensembles'))

