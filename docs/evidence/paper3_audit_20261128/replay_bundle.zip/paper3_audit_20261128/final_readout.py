"""Extend tables with the follow-up and draw the phase-separated principal figure."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
root=Path(__file__).resolve().parent
out=Path('/global/homes/d/dkololgi/TNG/Illustris/docs/evidence/paper3_audit_20261128')
read=lambda p:json.loads(p.read_text())
# The two score functions below use the same ECDF and unbiased-pair definitions as the development readout.
records=[]
for ph in ('ph018','ph019'):
    for r in read(root/(ph+'.json')):
        for subset,models in enumerate(r['scores']):
            for method,lags in models.items():
                for lag,v in lags.items():
                    v=np.sort(v);m=len(v);y=r['truth'][lag];absolute=np.abs(v-y).mean()
                    pairterm=np.dot(2*np.arange(1,m+1)-m-1,v)
                    lo,hi=np.quantile(v,[.05,.95])
                    records.append(dict(run='heldout',phase=ph,pair=r['pair'],lag=int(lag),method=method,subset=subset,m=m,truth=y,centre=v.mean(),bias=v.mean()-y,width=hi-lo,lo=lo,hi=hi,covered=int(lo<=y<=hi),below=int(y<lo),above=int(y>hi),rank=(v<y).sum(),ties=(v==y).sum(),sd=v.std(ddof=1),order_coverage=int(v[2]<=y<=v[-3]),fair=absolute-pairterm/(m*(m-1)),empirical=absolute-pairterm/m**2,redshift=r['redshift'],support=r['support'],cells=r['cells'],mask_hash=r['mask_hash']))
df=pd.DataFrame(records)
keys=['phase','pair','lag','subset']
cf=df[df.method=='cfm'][keys+['empirical','fair']].rename(columns={'empirical':'ce','fair':'cf'})
df=df.merge(cf,on=keys,validate='many_to_one')
df['gain_emp']=df.empirical-df.ce;df['gain_fair']=df.fair-df.cf
df['cfm_wins']=df.gain_emp>0;df['stratum_z']=np.where(df.redshift<.25,'low','high')
df.to_csv(out/'heldout_regions.csv.gz',index=False,compression='gzip')
allrows=pd.concat([pd.read_csv(out/'regions.csv.gz'),df],ignore_index=True)
g=['run','phase','lag','m','subset','method']
def summary(frame,cols):
    return frame.groupby(cols).agg(regions=('pair','size'),fair=('fair','mean'),empirical=('empirical','mean'),gain_emp=('gain_emp','mean'),gain_fair=('gain_fair','mean'),cfm_wins=('cfm_wins','sum'),truth=('truth','mean'),centre=('centre','mean'),error=('bias','mean'),width=('width','mean'),covered=('covered','sum'),below=('below','sum'),above=('above','sum'),rank=('rank','mean'),ties=('ties','sum'),covered_order3_to_Mminus2=('order_coverage','sum')).reset_index()
s=summary(allrows,g)
s.to_csv(out/'all_phase_scores.csv',index=False)
p=allrows[(allrows.m==20)&(allrows.subset==0)&allrows.method.isin(['cfm','ecc','shuffle711','baseline'])]
for f in ['support','stratum_z']:
    summary(p,g+[f]).to_csv(out/('all_'+f+'.csv'),index=False)
# Show the large independence penalty, then resolve the smaller rank-control contrast.
fig,axes=plt.subplots(2,5,figsize=(13.8,6.1),sharey='row',layout='constrained')
colors={'cfm':'#006c67','ecc':'#b14925','baseline':'#695684','shuffle711':'#657484'}
for j,ph in enumerate(sorted(p.phase.unique())):
    a,b=axes[:,j]
    for name,label in [('shuffle711','Shuffled CFM'),('baseline','Residual library'),('ecc','CFM with residual ranks'),('cfm','Coherent CFM')]:
        vals=p[(p.phase==ph)&(p.method==name)].groupby('lag').empirical.mean()
        a.plot([1,2,4],vals,'o-',color=colors[name],label=label,ms=4,lw=1.6)
    a.set_title(ph+'\n'+('Development' if j<3 else 'Held-out follow-up'),fontsize=11)
    a.set_xticks([1,2,4])
    for lag in [1,2,4]:
        vals=p[(p.phase==ph)&(p.method=='ecc')&(p.lag==lag)].sort_values('pair').gain_emp.values
        b.scatter(lag+np.linspace(-.17,.17,len(vals)),vals,s=12,alpha=.6,color=colors['ecc'])
        b.scatter(lag,vals.mean(),marker='D',color='black',s=25,zorder=4)
    b.axhline(0,color='0.45',lw=.7); b.set_xticks([1,2,4]);b.set_xlabel('Lag (cells)')
axes[0,0].set_ylabel('Empirical CRPS\n(lower is better)')
axes[1,0].set_ylabel('CRPS(rank control) − CRPS(CFM)')
fig.legend(*axes[0,0].get_legend_handles_labels(),loc='outside lower center',ncol=4,frameon=False)
fig.savefig(out/'filament_five_phases.pdf')
print(s[(s.run=='heldout')&(s.subset==0)&s.method.isin(['cfm','ecc','baseline','shuffle711'])][['phase','lag','method','fair','empirical','gain_emp','cfm_wins','truth','centre','width','below','above','rank']].round(6).to_string(index=False))

