import csv,json,hashlib
from pathlib import Path
import numpy as np, fitsio
root=Path(__file__).resolve().parent.parent
out=Path('/global/homes/d/dkololgi/TNG/Illustris/docs/evidence/paper3_audit_20261128')
read=lambda p:json.loads(p.read_text())
record=read(root/'lowz_loa_input_check_61811977/INPUT_CHECK.json')
with (out/'catalogue_trace.csv').open('x') as f:
    w=csv.writer(f); w.writerow(['catalogue','source_row_zero_based','TARGETID','RA','DEC','Z_not4clus','ZWARN','BGS_TARGET','PHOTSYS','SPECTYPE','DELTACHI2','receipt_domain'])
    for cat in ('loa','mock'):
        path=next(p for p in record['source_stats'] if p.endswith('.dat.fits') and ('/mocks/' in p)==(cat=='mock'))
        with fitsio.FITS(path) as h:
            names=['TARGETID','RA','DEC','Z_not4clus','ZWARN','BGS_TARGET','PHOTSYS']
            if cat=='loa':names+=['SPECTYPE','DELTACHI2']
            arr=h[1][names][0:4096]
            for target,z,warn,bgs,domain in record['rows'][cat]['ten_selected_rows']:
                ix=int(np.flatnonzero(arr['TARGETID']==target)[0]); a=arr[ix]
                assert a['Z_not4clus']==z and a['ZWARN']==warn and a['BGS_TARGET']==bgs
                w.writerow([cat,ix]+[a[n] for n in names]+([] if cat=='loa' else ['',''])+[domain])
cost={}
for cap in ('NGC','SGC'):
    d=root/'lowz_loa_response_61911856'/cap
    rows=[]
    maprec=read(d/'map_62099144/MAP_COMPLETE.json');assert maprec['passed']
    for i in range(32):
        p=d/'predictions'/f'draw_{i:03d}'
        den=read(p/'density/COMPLETE.json');tide=read(p/'tides/COMPLETE.json')
        assert den['passed'] and tide['passed'] and den['first']==tide['first']==i
        rows.append([den['windows'],den['prep_seconds'],den['solve_seconds'],tide['seconds'],den['mass_error'],tide['diagnostics'][0]['trace_maxabs']])
    a=np.array(rows);cost[cap]=dict(n=len(a),windows=list(map(int,np.unique(a[:,0]))),median_seconds=a[:,1:4].__array__().T.tolist() if False else np.median(a[:,1:4],axis=0).tolist(),sum_hours=a[:,1:4].sum(0).tolist(),max_mass=float(a[:,4].max()),max_trace=float(a[:,5].max()))
    cost[cap]['sum_hours']=[s/3600 for s in cost[cap]['sum_hours']]
(out/'loa_cost.json').write_text(json.dumps(cost,indent=2))
print(cost)
