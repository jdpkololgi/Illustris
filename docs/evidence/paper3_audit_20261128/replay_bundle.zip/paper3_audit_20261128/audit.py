"""Frozen development audit. Run on one CPU node. No inference or fit."""
import os, sys, json, hashlib, time
from pathlib import Path
ROOT = Path(__file__).resolve().parent
BASE = ROOT.parent
REPO = Path('/global/homes/d/dkololgi/TNG/Illustris')
DEPLOY = BASE.parent/'coarse_source_61551798'
os.environ['GRAPHWEB_CFM_DATA_CONFIG'] = str(DEPLOY/'configs/e2e_coupled_data_lowz_20261029.json')
sys.path[:0] = [str(DEPLOY), str(BASE.parent/'lowz_seed_gate_5ed6c27_5T9TfG'), str(REPO/'workflows/sbi')]
import numpy as np
import h5py
from scipy.ndimage import minimum_filter
from scipy.spatial.distance import pdist, cdist
import lowz_count_reference as ref

read=lambda p:json.loads(p.read_text())
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(name, obj):
    with (ROOT/name).open('x') as handle:
        json.dump(obj,handle,allow_nan=False,default=lambda x:x.item())
def fil(v):
    return (v[...,1:]>.2).sum(-1)==2
def cov(f,mask,lag):
    a,b=[],[]
    for axis in range(3):
        src=[slice(None)]*3
        dst=src.copy()
        src[axis]=slice(None,-lag)
        dst[axis]=slice(lag,None)
        src,dst=tuple(src),tuple(dst)
        keep=mask[src]&mask[dst]
        a.append(f[(slice(None),*src)][:,keep])
        b.append(f[(slice(None),*dst)][:,keep])
    a,b=np.concatenate(a,axis=1),np.concatenate(b,axis=1)
    assert a.shape[1]>0
    return (a&b).mean(1)-a.mean(1)*b.mean(1)
def rank(v):
    a,b=v[...,1],v[...,2]
    # Exact threshold logic. At margin zero put nonfilaments first, filaments last.
    margin=np.minimum(b-.2,.2-a)
    return np.lexsort((fil(v),margin),axis=0)
def rearrange(v,order):
    index=np.broadcast_to(order[...,None],v.shape)
    moved=np.take_along_axis(v,index,axis=0)
    # Verify the same intact tuples can be recovered at every cell.
    inv=np.argsort(order,axis=0)
    assert np.array_equal(np.take_along_axis(moved,inv[...,None],axis=0),v,equal_nan=True)
    assert np.array_equal(fil(v).sum(0),fil(moved).sum(0))
    return moved
def main():
    ref.c.require_compute()
    phases=ref.c.DEVELOPMENT
    assert phases==('ph006','ph012','ph013') and len(ref.c.TRAIN)==20
    archive=BASE/'lowz_calibration_61647276/CALIBRATION.json'
    paths=read(archive)['paths']
    fit=BASE/'lowz_count_reference_61848915/TRAIN_ONLY.npz'
    assert digest(fit)==read(fit.with_name('FIT.json'))['library']['sha256']
    coef=np.load(fit)['coef']
    subsets=[list(range(20)),list(range(12,32)),list(range(0,32,2))+[1,3,5,7]]
    seeds=[711,712,713]
    model_sizes={}
    for model in [ref.p.p.CoupledBackbone('coarse','wide',base=24,levels=3),ref.p.m.fine.t.FineModel('unet','x')]:
        model_sizes[type(model).__name__]=sum(p.numel() for p in model.parameters())
    save('freeze.json',dict(source=digest(Path(__file__)),original='84cd321',archive=digest(archive),fit=digest(fit),phases=phases,donors=ref.c.TRAIN,subsets=subsets,seeds=seeds,parameters=model_sizes,primary='empirical CRPS, 20 members, first subset/seed, paired equal-region means for each phase; lag 1 primary; 2,4 secondary; linear 5/95 coverage plus ranks. All regions retained. Centre is draw mean. Strata registered centre z below .25 or above, boundary/interior. Secondary peak ranks, boundary and ties.'))
    start=time.monotonic()
    bank={}
    for ph in ref.c.TRAIN:
        for row,(x,*_) in ref.groups(ph):
            y=ref.truth(ph,row)
            key=row['pair_id'].split('_',1)[1]
            bank.setdefault(key,[]).append((ref.encode(y.reshape(-1,4)).reshape(y.shape)-x@coef).astype('f4'))
    donor_sec=time.monotonic()-start
    old_rng=np.random.default_rng(711)
    results=[]
    for ph in phases:
        old={r['pair']:r for r in read(BASE/'spatial_venue_62121276'/(ph+'.json'))}
        for row,(x,z,s,sm,n) in ref.groups(ph):
            pair=row['pair_id']
            m=(z>=0)&(z<5)&(s>0)
            truth=ref.truth(ph,row)
            fields=[]
            for i in range(32):
                path=Path(paths[str((ph,row['cap'],i))])
                with h5py.File(path/'density/FIELD.h5') as f,h5py.File(path/'tides/COMPLETED_FIELD.h5') as g:
                    sl=ref.p.cuts(row,f.attrs['origin_mpc_h'])
                    np.testing.assert_array_equal(f['support'][sl]>0,s>0)
                    fields.append(np.concatenate([f['rho'][(0,*sl)][...,None],g['eigenvalues'][(0,*sl)]],axis=-1))
            fields=np.stack(fields)
            assert np.isfinite(fields[:,m]).all() and (np.diff(fields[:,m,1:],axis=-1)>=0).all()
            raw=x@coef+np.array(bank[pair.split('_',1)[1]])
            q,b,u,v=np.moveaxis(raw,-1,0)
            baseline=np.stack([np.exp(q),b-np.exp(u),b,b+np.exp(v)],-1)
            full=fil(fields)
            shuffled=np.take_along_axis(full,old_rng.random(full.shape).argsort(axis=0),axis=0)
            assert np.array_equal(full.sum(0),shuffled.sum(0))
            prob=full.mean(0); prob_s=shuffled.mean(0)
            y=fil(truth)
            assert np.array_equal((prob-y)**2,(prob_s-y)**2)
            donors=old_rng.integers(20,size=32)
            for lag in (1,2,4):
                for expected,a in zip(old[pair]['stats'][str(lag)],[y[None],full,shuffled,fil(baseline)[donors]]):
                    np.testing.assert_allclose(cov(a,m,lag),expected,atol=2e-15,rtol=0)
            rec=dict(pair=pair,phase=ph,redshift=row['redshift'],support=row['support_stratum'],cells=int(m.sum()),mask_hash=hashlib.sha256(m.tobytes()).hexdigest(),unique_donors=len(set(donors)),scores=[])
            # Peak diagnostics use the original observed count/support feature only.
            eligible=minimum_filter(m.astype('u1'),size=5,mode='constant')>0
            if eligible.any():
                center=np.unravel_index(np.argmax(np.where(eligible,x[...,1],-np.inf)),m.shape)
                hood=tuple(slice(i-2,i+3) for i in center)
                a=np.concatenate([truth[None,...,0],fields[...,0]])[(slice(None),*hood)].reshape(33,-1)
                pos=np.stack(np.unravel_index(a.argmax(1),(5,5,5)),axis=1)
                peaks=a.max(1)
                rec['peak']=dict(truth=peaks[0],mean=peaks[1:].mean(),median=np.median(peaks[1:]),meanfield_max=a[1:].mean(0).max(),rank=int((peaks[1:]<peaks[0]).sum()),ties=int(((a==peaks[:,None]).sum(1)>1).sum()),boundary=((pos==0)|(pos==4)).any(1).astype(int).tolist())
                np.testing.assert_allclose([cdist(pos[:1],pos[1:]).mean()*6.766,pdist(pos[1:]).mean()*6.766,peaks[0],np.median(peaks[1:])],old[pair]['peak'],rtol=1e-6)
            inv=rank(baseline).argsort(axis=0)
            for k,ids in enumerate(subsets):
                f=fields[ids]
                perm=np.take_along_axis(rank(f),inv,axis=0)
                ecc=rearrange(f,perm)
                rec['scores'].append({})
                ensembles={'cfm':fil(f),'baseline':fil(baseline),'ecc':fil(ecc)}
                for seed in seeds:
                    rng=np.random.default_rng([seed,int(ph[2:]),int(hashlib.sha256(pair.encode()).hexdigest()[:8],16)])
                    order=rng.random(f.shape[:-1]).argsort(0)
                    ensembles['shuffle'+str(seed)]=fil(rearrange(f,order))
                for name,ens in ensembles.items():
                    rec['scores'][-1][name]={str(d):cov(ens,m,d).tolist() for d in (1,2,4)}
            results.append(rec)
        save(ph+'.json',[r for r in results if r['phase']==ph])
        print(ph,'completed',flush=True)
    save('complete.json',dict(regions=len(results),donor_seconds=donor_sec,seconds=time.monotonic()-start,freeze=digest(ROOT/'freeze.json'),checks='all 48 original region draw vectors x all lags x four arms replayed; 32-member Bernoulli cell marginals and Brier identical; exact inverse tuple and filament count checks each 20-member rearrangement',files={p:digest(ROOT/(p+'.json')) for p in phases}))
if __name__=='__main__':main()
