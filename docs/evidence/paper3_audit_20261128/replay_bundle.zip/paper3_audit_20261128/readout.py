"""Read immutable regional vectors. Equal-region phase means. No field generation."""
import csv, json, hashlib
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
root=Path(__file__).resolve().parent
repo=Path('/global/homes/d/dkololgi/TNG/Illustris')
out=repo/'docs/evidence/paper3_audit_20261128'
orig=root.parent/'spatial_venue_62121276'
read=lambda p:json.loads(p.read_text())
rows=[]; peaks=[]
def vector(run, ph, pair, lag, method, subset, y, draws, meta):
    v=np.sort(draws); m=len(v)
    halfsum=np.dot(2*np.arange(1,m+1)-m-1,v)
    absolute=np.mean(abs(v-y))
    lo,hi=np.quantile(v,[.05,.95])
    rank=(v<y).sum(); ties=(v==y).sum()
    return dict(run=run,phase=ph,pair=pair,lag=int(lag),method=method,subset=subset,m=m,
        truth=y,centre=v.mean(),bias=v.mean()-y,width=hi-lo,lo=lo,hi=hi,covered=int(lo<=y<=hi),
        below=int(y<lo),above=int(y>hi),rank=rank,ties=ties,sd=v.std(ddof=1),
        order_coverage=int(v[2]<=y<=v[-3]),fair=absolute-halfsum/(m*(m-1)),
        empirical=absolute-halfsum/m**2,**meta)
for ph in ['ph006','ph012','ph013']:
    new={r['pair']:r for r in read(root/(ph+'.json'))}
    for o in read(orig/(ph+'.json')):
        p=o['pair'];r=new[p]
        meta={k:r[k] for k in ('redshift','support','cells','mask_hash','unique_donors')}
        if 'peak' in r:peaks.append(dict(phase=ph,pair=p,dist_truth=o['peak'][0],dist_draw=o['peak'][1],**r['peak']))
        for lag,(yy,*models) in o['stats'].items():
            for model,v in zip(['cfm','shuffle711','baseline'],models):
                rows.append(vector('original',ph,p,lag,model,0,yy[0],v,meta))
            for idx,sc in enumerate(r['scores']):
                for model,stats in sc.items():
                    rows.append(vector('matched',ph,p,lag,model,idx,yy[0],stats[lag],meta))
df=pd.DataFrame(rows)
keys=['run','phase','pair','lag','subset']
cf=df[df.method=='cfm'][keys+['empirical','fair']].rename(columns={'empirical':'ce','fair':'cf'})
df=df.merge(cf,on=keys,validate='many_to_one')
df['gain_emp']=df.empirical-df.ce;df['gain_fair']=df.fair-df.cf
df['cfm_wins']=df.gain_emp>0;df['stratum_z']=np.where(df.redshift<.25,'low','high')
df.to_csv(out/'regions.csv.gz',index=False,compression='gzip')
g=['run','phase','lag','m','subset','method']
def summary(frame,cols):
    return frame.groupby(cols).agg(regions=('pair','size'),fair=('fair','mean'),empirical=('empirical','mean'),gain_emp=('gain_emp','mean'),gain_fair=('gain_fair','mean'),cfm_wins=('cfm_wins','sum'),truth=('truth','mean'),centre=('centre','mean'),error=('bias','mean'),width=('width','mean'),covered=('covered','sum'),below=('below','sum'),above=('above','sum'),rank=('rank','mean'),ties=('ties','sum'),covered_order3_to_Mminus2=('order_coverage','sum')).reset_index()
s=summary(df,g)
s.to_csv(out/'phase_scores.csv',index=False)
primary=df[(df.run=='matched')&(df.subset==0)&df.method.isin(['cfm','ecc','baseline','shuffle711'])]
for factor in ['support','stratum_z']:
    summary(primary,g+[factor]).to_csv(out/(factor+'.csv'),index=False)
pd.DataFrame(peaks).to_json(out/'peaks.json',orient='records',indent=1)
# All 16 regions visible; phase means do not receive voxel-based error bars.
fig,axes=plt.subplots(2,3,figsize=(10.8,6.2),sharex='row',sharey='row',layout='constrained')
colors={'cfm':'#005f73','ecc':'#ab4829','baseline':'#766193','shuffle711':'#627077'}
for j,ph in enumerate(['ph006','ph012','ph013']):
    a=axes[0,j]; b=axes[1,j]
    for name,label in [('shuffle711','Shuffled CFM'),('baseline','Residual library'),('ecc','Residual ranks + CFM marginals'),('cfm','Coherent CFM')]:
        sel=primary[(primary.phase==ph)&(primary.method==name)]
        values=sel.groupby('lag').empirical.mean()
        a.plot([1,2,4],values,'o-',color=colors[name],label=label,lw=1.6,ms=4)
    a.set_title(ph);a.set_xticks([1,2,4]);a.set_xlabel('Separation (fine cells)')
    dm=primary[(primary.phase==ph)&(primary.method=='ecc')]
    for lag in [1,2,4]:
        vals=dm[dm.lag==lag].sort_values('pair').gain_emp.to_numpy()
        b.scatter(lag+np.linspace(-.18,.18,len(vals)),vals,s=14,alpha=.65,color=colors['ecc'])
        b.scatter(lag,vals.mean(),marker='D',color='black',s=30,zorder=3)
    b.axhline(0,color='0.45',lw=.8);b.set_xticks([1,2,4]);b.set_xlabel('Separation (fine cells)')
axes[0,0].set_ylabel('Empirical CRPS  (lower is better)')
axes[1,0].set_ylabel('CRPS(rank control) − CRPS(CFM)')
fig.legend(*axes[0,0].get_legend_handles_labels(),loc='outside lower center',ncol=2,frameon=False)
fig.savefig(out/'filament_dependence.pdf')
print(s[(s.subset==0)&s.method.isin(['cfm','ecc','baseline','shuffle711'])][['run','phase','lag','method','fair','empirical','gain_emp','cfm_wins','error','width','covered','below','above','rank']].round(5).to_string(index=False))

